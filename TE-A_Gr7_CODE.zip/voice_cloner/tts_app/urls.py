from django.urls import path
from django.contrib.auth.views import LogoutView
from . import views

urlpatterns = [
    path("", views.index, name="tts_index"),
    path("history/", views.history, name="tts_history"),
    path("item/<int:pk>/", views.detail, name="detail"),
    path("item/<int:pk>/download/", views.download_output, name="tts_download"),
    path("logout/", LogoutView.as_view(next_page="login"), name="logout"),
]
