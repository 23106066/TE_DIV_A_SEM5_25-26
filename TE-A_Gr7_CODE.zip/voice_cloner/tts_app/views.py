import os
import io
import uuid
import re
from pathlib import PurePosixPath
from functools import lru_cache
from django.shortcuts import render, redirect, get_object_or_404
from django.http import FileResponse, Http404
from django.contrib.auth.decorators import login_required
from pydub import AudioSegment
from .forms import TTSForm
from .models import GeneratedAudio


# ========== TTS LOADER ==========
@lru_cache(maxsize=1)
def get_tts():
    """
    Load XTTS v2 model once and cache it for the entire process.
    """
    from TTS.api import TTS
    # Load once, use GPU if available for much faster inference
    return TTS("tts_models/multilingual/multi-dataset/xtts_v2", gpu=True)


# ========== TEXT CHUNKING ==========
def _split_text_into_chunks(text: str, language: str) -> list[str]:
    """
    Split text into ~350-character chunks at punctuation.
    This improves XTTS fluency and avoids cutoff in long text.
    Marathi uses Devanagari punctuation, so treat it like Hindi.
    """
    max_chars = 120  # increased from 160 → faster (fewer TTS calls)

    # Normalize language for regex (Marathi uses Devanagari)
    if language in ["hi", "mr"]:
        pattern = r'([,;:.?।॥]|\n)'
    else:
        pattern = r'([,;:.?]|\n)'

    pieces = re.split(pattern, text.strip())
    chunks, current = [], ""

    for piece in pieces:
        piece = piece.strip()
        if not piece:
            continue

        if len(current) + len(piece) + 1 <= max_chars:
            current += (" " if current else "") + piece
        else:
            if current:
                chunks.append(current.strip())
            current = piece

    if current:
        chunks.append(current.strip())

    return chunks


# ========== MERGE AUDIO ==========
def _merge_audio_segments(chunks: list[AudioSegment], output_path: str):
    """
    Merge AudioSegments directly (no temp file reads).
    Normalize final loudness and save once.
    """
    if not chunks:
        return

    combined = chunks[0]
    for seg in chunks[1:]:
        combined += seg

    # Normalize loudness slightly to prevent clipping
    combined = combined.apply_gain(-combined.max_dBFS)
    combined.export(output_path, format="wav")


# ========== MAIN TTS VIEW ==========
@login_required
def index(request):
    form = TTSForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        # --- User input ---
        text = form.cleaned_data["text"][:5000]
        language = form.cleaned_data["language"]   # will include "mr" for Marathi
        ref_file = form.cleaned_data.get("reference_audio")
        voice_option = request.POST.get("voice_option")  # male/female/custom

        # --- Folders ---
        out_dir = os.path.join("media", "outputs")
        ref_dir = os.path.join("media", "references")
        os.makedirs(out_dir, exist_ok=True)
        os.makedirs(ref_dir, exist_ok=True)

        out_fname = f"{uuid.uuid4()}.wav"
        out_path = os.path.join(out_dir, out_fname)

        # --- Language Normalization ---
        tts_language = "hi" if language == "mr" else language

        # --- Voice selection ---
        speaker_path, rel_ref = None, None
        if voice_option in ["male", "female"]:
            candidate = os.path.join(ref_dir, f"{voice_option}.wav")
            if os.path.exists(candidate):
                speaker_path = candidate
                rel_ref = str(PurePosixPath("references") / f"{voice_option}.wav")
        elif voice_option == "custom" and ref_file:
            ref_ext = os.path.splitext(ref_file.name)[1]
            ref_name = f"{uuid.uuid4()}{ref_ext}"
            ref_path = os.path.join(ref_dir, ref_name)
            with open(ref_path, "wb+") as dest:
                for chunk in ref_file.chunks():
                    dest.write(chunk)
            speaker_path = ref_path
            rel_ref = str(PurePosixPath("references") / ref_name)

        # --- Text Splitting ---
        chunks = _split_text_into_chunks(text, language)

        # --- TTS Generation ---
        tts = get_tts()
        audio_segments = []

        for chunk_text in chunks:
            try:
                # Generate audio in memory (no temp disk files)
                buffer = io.BytesIO()
                tts_args = {
                    "text": chunk_text,
                    "file_path": buffer,
                    "language": tts_language,
                }
                if speaker_path:
                    tts_args["speaker_wav"] = speaker_path

                tts.tts_to_file(**tts_args)
                buffer.seek(0)
                audio_segments.append(AudioSegment.from_file(buffer, format="wav"))
            except Exception as e:
                print(f"[TTS chunk error] {e}")

        # --- Merge and Export ---
        _merge_audio_segments(audio_segments, out_path)

        # --- Save DB Record ---
        rel_output = str(PurePosixPath("outputs") / out_fname)
        audio_obj = GeneratedAudio.objects.create(
            user=request.user,
            text=text,
            language=language,
            reference_audio=rel_ref,
            output_audio=rel_output,
        )
        return redirect("detail", pk=audio_obj.pk)

    # Recent audios for UI
    recent = GeneratedAudio.objects.filter(user=request.user).order_by("-created_at")[:8]
    return render(request, "tts_app/index.html", {"form": form, "recent_audios": recent})


# ========== OTHER VIEWS ==========
@login_required
def detail(request, pk):
    audio = get_object_or_404(GeneratedAudio, pk=pk, user=request.user)
    return render(request, "tts_app/detail.html", {"audio": audio})


@login_required
def history(request):
    audios = GeneratedAudio.objects.filter(user=request.user).order_by("-created_at")
    return render(request, "tts_app/history.html", {"audios": audios})


@login_required
def download_output(request, pk):
    audio = get_object_or_404(GeneratedAudio, pk=pk, user=request.user)
    file_path = audio.output_audio.path
    if not os.path.exists(file_path):
        raise Http404("File not found")
    return FileResponse(open(file_path, "rb"), as_attachment=True, filename=os.path.basename(file_path))

