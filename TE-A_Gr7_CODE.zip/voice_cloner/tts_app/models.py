from django.db import models
from django.contrib.auth.models import User

class GeneratedAudio(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="audios")
    text = models.TextField()
    language = models.CharField(max_length=10)
    reference_audio = models.FileField(upload_to="references/", blank=True, null=True)
    output_audio = models.FileField(upload_to="outputs/")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.language} – {self.text[:30]}"
