from django import forms

LANG_CHOICES = [
    ("en", "English"),
    ("es", "Spanish"),
    ("fr", "French"),
    ("hi", "Hindi"),
]


class TTSForm(forms.Form):
    text = forms.CharField(
        label="Text to speak",
        widget=forms.Textarea(attrs={"rows": 4, "class": "form-control"}),
    )
    language = forms.ChoiceField(choices=LANG_CHOICES, label="Language",
                                 widget=forms.Select(attrs={"class": "form-select"}))
    reference_audio = forms.FileField(label="Reference voice (optional)", required=False)
